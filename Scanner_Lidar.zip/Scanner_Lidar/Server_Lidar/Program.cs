﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NLog;
using Server_Lidar.Models;
using Server_Lidar.Services;
using System;
using System.Collections.Generic;
using System.IO;

namespace Server_Lidar
{
    class Program
    {
        private static int SERVER_PORT;
        private static Logger myLogger = LogManager.GetCurrentClassLogger();
        //private static List<Vector3> vector3s = new List<Vector3> {
        //    new Vector3
        //    {

        //        X = 50,
        //        Y = 93,
        //        Z = 69
        //    },
        //    new Vector3{
        //        X = 85,
        //        Y= 5,
        //        Z = 52
        //    },
        //    new Vector3{
        //        X = 77,
        //        Y= 55,
        //        Z = 98
        //    },
        //    new Vector3{
        //        X = 93,
        //        Y= 12,
        //        Z = 13
        //    },
        //    new Vector3{
        //        X = 14,
        //        Y= 68,
        //        Z = 13
        //    }
        //};
        static void Main(string[] args)
        {
            Console.Title = "Server";
            SERVER_PORT = 12345;
            var host = Host.CreateDefaultBuilder()
                  .ConfigureServices((context, services) =>
                  {
                      ConfigureServices(context.Configuration, services);
                  })
                  .ConfigureLogging((context, logging) => {
                      logging.AddConfiguration(context.Configuration.GetSection("Logging"));
                      logging.AddConsole();
                      logging.AddFilter("Microsoft.EntityFrameworkCore.Database.Command", Microsoft.Extensions.Logging.LogLevel.Warning);
                      logging.AddFilter("Microsoft.EntityFrameworkCore.Infrastructure", Microsoft.Extensions.Logging.LogLevel.Warning);
                  })
                  .Build();
            var db = host.Services.GetRequiredService<IVector3Repository>();
            //115200
            Server server = new Server(SERVER_PORT, "COM4",9600);
            try
            {
                server.Start();
            }
            catch (Exception e)
            {
                myLogger.Error(e.Message);
            }
            finally
            {
                server.Stop();
            }
            Console.WriteLine("\n Press any key to continue...");
            Console.ReadKey();
        }

        private static void ConfigureServices(IConfiguration configuration, IServiceCollection services)
        {

            string connection = "Data Source =" + Path.Combine(AppContext.BaseDirectory, @"..\..\..\Database\Lidar.3AA.db");
            services.AddDbContext<AppDbContext>(options => options.UseSqlite(connection));

            services.AddSingleton<IVector3Repository, VectorDbDataRepository>();
        }
    }
}
